#coding=utf8

#Tic-Tac-Toe

from game import (print_game, is_in_board, can_put, get_mark, is_finish, mark_num, whose_turn, put_mark)


# 读取文件, 定义两玩家的棋子
config = open("config.txt").read().strip()
PLAYER1, PLAYER2 = config.split(",")


# 初始化一个空的棋盘
game_state = [
    ["", "", ""],
    ["", "", ""],
    ["", "", ""],
]


# 始终循环 直到游戏结束
while not is_finish(game_state)[0]:

    # 落子先先打印出当前的棋局状态
    print_game(game_state)

    # 邀请玩家输入落子的坐标
    now_player = whose_turn(game_state, PLAYER1, PLAYER2)
    print "This is %s's turn." % now_player

    # 循环, 直到输入正确的坐标
    i, j = -1, -1
    while not can_put(i, j, game_state):
        try:
            posation = raw_input("Please enter the position which you want to put (such as '2,0'):")
            i, j = posation.split(",")
            i = int(i)
            j = int(j)
        except Exception, e:
            print e
            print "input error"

    # 落子
    put_mark(now_player, i, j, game_state)

    print "======================================"


# 游戏结束后打印出最终的棋局
print_game(game_state)

# 获取胜利者
winner = is_finish(game_state)[1]

# 打印出结局提示语
if not winner:
    print "The game ended in a draw."
else:
    print "Game is over, the winner is %s!" % winner

raw_input("Press enter to quit...")















