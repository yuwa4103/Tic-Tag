#coding=utf8


# 游戏可调用的方法

# 打印当前棋局
def print_game(game_state):
    # 用两个 for 循环来打印出二维棋盘布局
    size = len(game_state)
    print "\t0\t1\t2"
    for i in range(size):
        print "%d\t" % i,
        for j in range(size):
            mark = game_state[i][j]
            print "%s\t" % mark,
        print


# 判断坐标点是否在棋盘上
def is_in_board(i, j, game_state):
    size = len(game_state)
    if i >= size or j >= size:
        return False
    if i < 0 or j < 0:
        return False
    return True


# 判断坐标点是否可以落子
def can_put(i, j, game_state):
    if is_in_board(i, j, game_state) and game_state[i][j] == "":
        return True
    else:
        return False


# 获取棋盘上指定点的棋子
def get_mark(i, j, game_state):
    return game_state[i][j]


# 判断棋局是否结束了, 如果结束, 还会返回胜利者的记号, 打平胜利者为空
def is_finish(game_state):
    size = len(game_state)
    flag = False
    for i in range(size):
        for j in range(size):
            mark0 = get_mark(i, j, game_state)
            if mark0 == "":
                flag = True
                continue
            # case 1
            # X
            #  X
            #   X
            if is_in_board(i+1, j+1, game_state) and is_in_board(i+2, j+2, game_state):
                mark1 = get_mark(i+1, j+1, game_state)
                mark2 = get_mark(i+2, j+2, game_state)
                if mark0 == mark1 == mark2:
                    return True, mark0

            # case 2
            #   X
            #  X
            # X
            if is_in_board(i+1, j-1, game_state) and is_in_board(i+2, j-2, game_state):
                mark1 = get_mark(i+1, j-1, game_state)
                mark2 = get_mark(i+2, j-2, game_state)
                if mark0 == mark1 == mark2:
                    return True, mark0

            # case 3
            #  X
            #  X
            #  X
            if is_in_board(i, j+1, game_state) and is_in_board(i, j+2, game_state):
                mark1 = get_mark(i, j+1, game_state)
                mark2 = get_mark(i, j+2, game_state)
                if mark0 == mark1 == mark2:
                    return True, mark0

            # case 4
            # 
            # XXX
            # 
            if is_in_board(i+1, j, game_state) and is_in_board(i+2, j, game_state):
                mark1 = get_mark(i+1, j, game_state)
                mark2 = get_mark(i+2, j, game_state)
                if mark0 == mark1 == mark2:
                    return True, mark0

    # 判断如果棋盘上还有空为就没结束, 否则游戏结束打平
    if flag:
        return False, None
    else:
        return True, ""


# 统计棋盘上棋子的数量
def mark_num(mark, game_state):
    num = 0
    for line in game_state:
        for m in line:
            if m == mark:
                num += 1
    return num


# 判断当前应该是谁的下子
def whose_turn(game_state, player1, player2):
    if mark_num(player1, game_state) > mark_num(player2, game_state):
        return player2
    else:
        return player1


# 在棋盘上落子
def put_mark(mark, i, j, game_state):
    game_state[i][j] = mark















